﻿namespace CliWrap.Utils;

internal static class BufferSizes
{
    public const int Stream = 81920;
    public const int StreamReader = 1024;
}